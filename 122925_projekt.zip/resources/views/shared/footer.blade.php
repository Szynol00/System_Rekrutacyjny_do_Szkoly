<footer class="bg-dark text-light mt-5 custom-footer fixed-bottom">
    <div class="container">
        <div class="d-flex justify-content-between">
            <div>
                <a href="tel:123456789" class="text-light me-4">
                    <i class="bi bi-telephone-fill me-2"></i>+12 345 6789
                </a>
                <a href="mailto:example@example.com" class="text-light">
                    <i class="bi bi-envelope-fill me-2"></i>lo.XVrz@example.com
                </a>
            </div>
            <div>
                <span>Odwiedź nas na: </span>
                <a href="#" class="text-light me-3"><i class="bi bi-twitter"></i></a>
                <a href="#" class="text-light me-3"><i class="bi bi-facebook"></i></a>
                <a href="#" class="text-light me-3"><i class="bi bi-youtube"></i></a>
                <a href="#" class="text-light"><i class="bi bi-instagram"></i></a>
            </div>
        </div>
    </div>
</footer>
